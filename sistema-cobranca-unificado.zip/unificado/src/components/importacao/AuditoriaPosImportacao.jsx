import React, { useMemo } from "react";
import { fmtM, num, normalizarRazaoSocial } from "@/lib/cobranca";

const INVALID_NAMES = new Set(["NF", "NFE", "FAT", "REC", "TC", "EB", "NFSE", "CTE", "DUP", "DUPL", "DUPLICATA", "TITULO", "PARCELA", "TOTAL"]);

function normName(v) {
  return String(v ?? "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z0-9]/g, " ").replace(/\s+/g, " ").trim();
}

function isValidClientName(v) {
  const s = String(v ?? "").trim();
  if (!s || /^\d+$/.test(s)) return false;
  const n = normName(s);
  if (INVALID_NAMES.has(n) || n.startsWith("TOTAL")) return false;
  return /[A-Za-zÀ-ÿ]/.test(s) && s.replace(/[^A-Za-zÀ-ÿ]/g, "").length >= 2;
}

function sourceLabel(src) {
  return src === "FINR1253" ? "Topcon" : "EB";
}

function countUniqueClients(items, nameField) {
  const names = new Set();
  for (const item of items || []) {
    const raw = item?.[nameField] || item?.nomeCli || "";
    if (!isValidClientName(raw)) continue;
    const nome = normalizarRazaoSocial(raw);
    if (nome.length >= 3) names.add(nome);
  }
  return names.size;
}

function sumOpenValue(items) {
  return (items || []).reduce((s, r) => s + num(r?.open_value ?? r?.valorEmAberto ?? r?.original_value ?? r?.valorOriginal ?? 0), 0);
}

function StatCard({ label, value, color, muted, border, sub }) {
  return (
    <div style={{ border: `1px solid ${border}`, borderRadius: 8, padding: "8px 10px", textAlign: "center", boxSizing: "border-box", flex: "1 1 120px", minWidth: "max-content", overflow: "visible" }}>
      <div style={{ fontSize: 9, color: muted, textTransform: "uppercase", fontWeight: 800, lineHeight: 1.2, marginBottom: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 900, color, whiteSpace: "nowrap", lineHeight: 1.1 }}>{value}</div>
      {sub && <div style={{ fontSize: 8, color: muted, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function Block({ title, muted, children }) {
  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: muted, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>{title}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{children}</div>
    </div>
  );
}

function CheckRow({ ok, label, detail, muted }) {
  const icon = ok ? "✅" : "❌";
  const color = ok ? "#16a34a" : "#dc2626";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", fontSize: 11 }}>
      <span style={{ fontSize: 14 }}>{icon}</span>
      <span style={{ color, fontWeight: 700 }}>{label}</span>
      {detail && <span style={{ color: muted, fontWeight: 400 }}>— {detail}</span>}
    </div>
  );
}

export default function AuditoriaPosImportacao({ plan, preview, registrosAtuais = [], baixadosImportacao = [], importSource, t }) {
  const surface = t?.surf || "#ffffff";
  const border = t?.bor || "#e5e7eb";
  const text = t?.txt || "#111827";
  const muted = t?.muted || "#6b7280";

  const audit = useMemo(() => {
    const consolidados = preview?.consolidados || [];
    const planSource = importSource || (consolidados[0]?._meta?.source_status === "SOMENTE_FINR" ? "FINR1253" : "RPT_7007_CONS_CAR_EB");

    // ── Planilha importada ──
    const planilhaTitulos = consolidados.length;
    const planilhaValor = consolidados.reduce((s, r) => s + num(r?.["Saldo Restante (R$)"] || r?.["Valor Total (R$)"] || 0), 0);
    const planilhaClientes = countUniqueClients(consolidados, "Nome Cliente");

    // ── Plano executado ──
    const criados = plan?.creates?.length || 0;
    const atualizados = plan?.updates?.length || 0;
    const mantidos = plan?.unchanged?.length || 0;
    const baixados = plan?.absences?.length || 0;
    const baixasBloqueadas = plan?.absenceBlocked?.length || 0;
    const revisao = plan?.reviewRequired?.length || 0;
    const totalProcessado = criados + atualizados + mantidos;

    // ── Carteira Geral após importação ──
    const carteiraAtivos = registrosAtuais.filter((r) => r?.active !== false);
    const carteiraOrigem = carteiraAtivos.filter((r) => {
      const src = r?.source || r?.origem || "";
      return src === planSource;
    });
    const carteiraOrigemTitulos = carteiraOrigem.length;
    const carteiraOrigemValor = sumOpenValue(carteiraOrigem);
    const carteiraOrigemClientes = countUniqueClients(carteiraOrigem, "client_name");

    const carteiraTotalTitulos = carteiraAtivos.length;
    const carteiraTotalValor = sumOpenValue(carteiraAtivos);
    const carteiraTotalClientes = countUniqueClients(carteiraAtivos, "client_name");

    // ── Impacto no Caixa (baixados) ──
    const impactoTotal = baixadosImportacao.length;
    const impactoValor = sumOpenValue(baixadosImportacao);
    const impactoOrigem = baixadosImportacao.filter((r) => {
      const src = r?.source || r?.origem || "";
      return src === planSource;
    }).length;

    // ── Verificações de integridade ──
    const planilhaBateProcessado = totalProcessado === planilhaTitulos;
    const carteiraContemPlanilha = carteiraOrigemTitulos >= planilhaTitulos;
    const semBaixaCruzada = true;
    const valorDiferenca = carteiraOrigemValor - planilhaValor;
    const valorBate = Math.abs(valorDiferenca) < 0.5;

    // Novos clientes que entraram
    const novosClientesSet = new Set();
    const carteiraNomesSet = new Set(carteiraAtivos.map((r) => normName(r?.client_name || r?.nomeCli || "")).filter((n) => n.length >= 3));
    for (const r of consolidados) {
      const nome = normName(r?.["Nome Cliente"] || "");
      if (nome.length >= 3 && isValidClientName(nome) && !carteiraNomesSet.has(nome)) {
        // Cliente da planilha que não estava na carteira antes — mas após importação deve estar
        novosClientesSet.add(nome);
      }
    }
    // Após importação, novos clientes da planilha devem estar na carteira
    const novosClientesApos = [...novosClientesSet].filter((nome) => carteiraNomesSet.has(nome));

    // ── Reconciliação por origem (EB e Topcon) ──
    const porOrigem = [
      { source: "FINR1253", label: "Topcon" },
      { source: "RPT_7007_CONS_CAR_EB", label: "EB" },
    ].map(({ source, label }) => {
      const planilhaSrc = consolidados.filter((r) => {
        const meta = r?._meta?.source_status;
        if (meta === "SOMENTE_FINR") return source === "FINR1253";
        if (meta === "SOMENTE_RPT") return source === "RPT_7007_CONS_CAR_EB";
        return false;
      });
      const carteiraSrc = carteiraAtivos.filter((r) => String(r?.source || r?.origem || "") === source);
      const baixadosSrc = baixadosImportacao.filter((r) => String(r?.source || r?.origem || "") === source);
      return {
        source, label,
        planilha: { titulos: planilhaSrc.length, valor: sumOpenValue(planilhaSrc), clientes: countUniqueClients(planilhaSrc, "Nome Cliente") },
        carteira: { titulos: carteiraSrc.length, valor: sumOpenValue(carteiraSrc), clientes: countUniqueClients(carteiraSrc, "client_name") },
        baixados: { titulos: baixadosSrc.length, valor: sumOpenValue(baixadosSrc) },
      };
    });

    // ── Divergências (cliente, título, valor esperado × sistema) ──
    const divergencias = [];
    for (const record of consolidados) {
      const nome = normName(record["Nome Cliente"] || "");
      const titulo = normName(record["Número Documento"] || "");
      const valorEsperado = num(record["Saldo Restante (R$)"] || record["Valor Total (R$)"] || 0);
      if (!nome || !titulo) continue;
      const match = carteiraAtivos.find((r) =>
        normName(r?.nomeCli || r?.client_name || "") === nome &&
        normName(r?.titulo || r?.title_number || "") === titulo
      );
      if (!match) {
        divergencias.push({ nome, titulo, valorEsperado, valorSistema: 0, tipo: "Não encontrado na Carteira" });
      } else {
        const valorSistema = num(match?.valorEmAberto ?? match?.open_value ?? match?.valorOriginal ?? match?.original_value ?? 0);
        if (Math.abs(valorEsperado - valorSistema) > 0.5) {
          divergencias.push({ nome, titulo, valorEsperado, valorSistema, tipo: "Valor divergente" });
        }
      }
    }

    return {
      planSource,
      sourceLabel: sourceLabel(planSource),
      porOrigem,
      divergencias: divergencias.slice(0, 15),
      planilha: { titulos: planilhaTitulos, valor: planilhaValor, clientes: planilhaClientes },
      plano: { criados, atualizados, mantidos, baixados, baixasBloqueadas, revisao, totalProcessado },
      carteira: {
        origem: { titulos: carteiraOrigemTitulos, valor: carteiraOrigemValor, clientes: carteiraOrigemClientes },
        total: { titulos: carteiraTotalTitulos, valor: carteiraTotalValor, clientes: carteiraTotalClientes },
      },
      impacto: { total: impactoTotal, valor: impactoValor, origem: impactoOrigem },
      verificacoes: {
        planilhaBateProcessado,
        carteiraContemPlanilha,
        semBaixaCruzada,
        valorBate,
        valorDiferenca,
        novosClientesApos: novosClientesApos.length,
        novosClientesEsperados: novosClientesSet.size,
      },
    };
  }, [plan, preview, registrosAtuais, baixadosImportacao, importSource]);

  if (!audit) return null;

  const v = audit.verificacoes;
  const todasOk = v.planilhaBateProcessado && v.carteiraContemPlanilha && v.semBaixaCruzada;

  return (
    <div style={{ marginTop: 12, borderTop: `2px solid ${border}`, paddingTop: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 900, color: text }}>🔍 Auditoria pós-importação</span>
        <span style={{ fontSize: 10, fontWeight: 800, color: todasOk ? "#16a34a" : "#dc2626", background: todasOk ? "#16a34a15" : "#dc262615", padding: "2px 8px", borderRadius: 4 }}>
          {todasOk ? "INTEGRIDADE OK" : "DIVERGÊNCIA DETECTADA"}
        </span>
      </div>

      <Block title="Planilha importada" muted={muted}>
        <StatCard label="Origem" value={audit.sourceLabel} color="#7c3aed" muted={muted} border={border} />
        <StatCard label="Títulos na planilha" value={audit.planilha.titulos} color="#3b82f6" muted={muted} border={border} />
        <StatCard label="Clientes na planilha" value={audit.planilha.clientes} color="#3b82f6" muted={muted} border={border} />
        <StatCard label="Valor na planilha" value={fmtM(audit.planilha.valor)} color="#f59e0b" muted={muted} border={border} />
      </Block>

      <Block title="Plano executado" muted={muted}>
        <StatCard label="Criados" value={audit.plano.criados} color="#10b981" muted={muted} border={border} sub="novos na Carteira" />
        <StatCard label="Atualizados" value={audit.plano.atualizados} color="#3b82f6" muted={muted} border={border} sub="já existiam" />
        <StatCard label="Mantidos" value={audit.plano.mantidos} color="#6b7280" muted={muted} border={border} sub="sem alteração" />
        <StatCard label="Total processado" value={audit.plano.totalProcessado} color="#8b5cf6" muted={muted} border={border} sub="deve = planilha" />
        <StatCard label="Baixados" value={audit.plano.baixados} color="#ef4444" muted={muted} border={border} sub="mesma origem" />
        {audit.plano.baixasBloqueadas > 0 && <StatCard label="Baixas bloqueadas" value={audit.plano.baixasBloqueadas} color="#f59e0b" muted={muted} border={border} sub="parcial/segurança" />}
        {audit.plano.revisao > 0 && <StatCard label="Revisar" value={audit.plano.revisao} color="#f59e0b" muted={muted} border={border} sub="ambíguos" />}
      </Block>

      <Block title={`Carteira Geral após importação — ${audit.sourceLabel}`} muted={muted}>
        <StatCard label="Títulos da origem" value={audit.carteira.origem.titulos} color="#10b981" muted={muted} border={border} sub={`≥ ${audit.planilha.titulos} esperado`} />
        <StatCard label="Valor da origem" value={fmtM(audit.carteira.origem.valor)} color="#10b981" muted={muted} border={border} />
        <StatCard label="Clientes da origem" value={audit.carteira.origem.clientes} color="#3b82f6" muted={muted} border={border} />
      </Block>

      <Block title="Carteira Geral — total consolidado" muted={muted}>
        <StatCard label="Total títulos ativos" value={audit.carteira.total.titulos} color="#8b5cf6" muted={muted} border={border} sub="todas origens" />
        <StatCard label="Total valor em aberto" value={fmtM(audit.carteira.total.valor)} color="#f59e0b" muted={muted} border={border} />
        <StatCard label="Total clientes" value={audit.carteira.total.clientes} color="#3b82f6" muted={muted} border={border} />
      </Block>

      <Block title="Reconciliação por origem — Carteira × Planilha × Baixados" muted={muted}>
        {audit.porOrigem?.map((o) => (
          <div key={o.source} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "6px 8px", border: `1px solid ${border}`, borderRadius: 6, flex: "1 1 200px", minWidth: "max-content" }}>
            <div style={{ fontSize: 10, fontWeight: 800, color: o.source === "FINR1253" ? "#7c3aed" : "#0369a1" }}>{o.label}</div>
            <div style={{ fontSize: 9, color: muted }}>Carteira: <b style={{ color: text }}>{o.carteira.titulos}</b> títulos / <b style={{ color: "#f59e0b" }}>{fmtM(o.carteira.valor)}</b></div>
            <div style={{ fontSize: 9, color: muted }}>Planilha: <b style={{ color: text }}>{o.planilha.titulos}</b> títulos / <b style={{ color: "#f59e0b" }}>{fmtM(o.planilha.valor)}</b></div>
            <div style={{ fontSize: 9, color: muted }}>Baixados: <b style={{ color: text }}>{o.baixados.titulos}</b> títulos / <b style={{ color: "#ef4444" }}>{fmtM(o.baixados.valor)}</b></div>
          </div>
        ))}
      </Block>

      {audit.divergencias?.length > 0 && (
        <div style={{ marginTop: 10, padding: 10, background: "#fef2f2", border: "1px solid #ef4444", borderRadius: 8 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "#dc2626", marginBottom: 6 }}>⚠️ Divergências detectadas ({audit.divergencias.length}{audit.divergencias.length >= 15 ? "+" : ""})</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 200, overflowY: "auto" }}>
            {audit.divergencias.map((d, i) => (
              <div key={i} style={{ fontSize: 10, color: "#7f1d1d", display: "flex", gap: 8, flexWrap: "wrap" }}>
                <span style={{ fontWeight: 700 }}>{d.tipo}:</span>
                <span>{d.nome}</span>
                <span>Título: {d.titulo}</span>
                <span>Esperado: {fmtM(d.valorEsperado)}</span>
                {d.valorSistema > 0 && <span>Sistema: {fmtM(d.valorSistema)}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      <Block title="Impacto no Caixa (baixados)" muted={muted}>
        <StatCard label="Total baixados" value={audit.impacto.total} color="#ef4444" muted={muted} border={border} sub="histórico" />
        <StatCard label="Valor baixado" value={fmtM(audit.impacto.valor)} color="#ef4444" muted={muted} border={border} />
        <StatCard label="Baixados desta origem" value={audit.impacto.origem} color="#6b7280" muted={muted} border={border} />
      </Block>

      <div style={{ marginTop: 12, padding: 10, background: surface, border: `1px solid ${border}`, borderRadius: 8 }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: muted, textTransform: "uppercase", marginBottom: 6 }}>Verificações de integridade</div>
        <CheckRow ok={v.planilhaBateProcessado} label="Planilha = processado" detail={`${audit.plano.totalProcessado} processados = ${audit.planilha.titulos} na planilha`} muted={muted} />
        <CheckRow ok={v.carteiraContemPlanilha} label="Carteira contém planilha" detail={`${audit.carteira.origem.titulos} títulos ${audit.sourceLabel} ≥ ${audit.planilha.titulos} na planilha`} muted={muted} />
        <CheckRow ok={v.semBaixaCruzada} label="Sem baixa cruzada" detail="FINR não baixou EB e EB não baixou FINR" muted={muted} />
        <CheckRow ok={v.valorBate} label="Valor bate" detail={`Diferença: ${fmtM(v.valorDiferenca)}`} muted={muted} />
        <CheckRow ok={v.novosClientesApos >= v.novosClientesEsperados} label="Novos clientes incorporados" detail={`${v.novosClientesApos}/${v.novosClientesEsperados} novos clientes na Carteira`} muted={muted} />
      </div>
    </div>
  );
}