import { createClient } from '@supabase/supabase-js';

// Lê as credenciais do projeto Supabase a partir das variáveis de ambiente (Vite).
// Defina-as em um arquivo .env (local) e nos secrets do GitHub (deploy).
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Flag que o resto do app usa para saber se o Supabase está pronto.
// Se NÃO estiver configurado, o app continua funcionando em modo local
// (IndexedDB/localStorage) — nunca quebra por falta de credencial.
export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

if (!isSupabaseConfigured) {
  console.info(
    '[Supabase] Credenciais ausentes (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY). ' +
    'Rodando em modo LOCAL. Configure o .env para ligar o banco.'
  );
}

// Só cria o client se houver credenciais; caso contrário exporta null.
export const supabase = isSupabaseConfigured
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true },
    })
  : null;
