// ============================================================================
// CAMADA DE DADOS — Supabase (com fallback local)
// ----------------------------------------------------------------------------
// Continua exportando `base44` com a MESMA interface usada pelo app
// (base44.entities.Titulo.list/filter/create/update/bulkCreate/bulkUpdate/
// subscribe). A diferença: o "remoto" agora é o SUPABASE, não a Base44.
// Nenhum componente precisou ser alterado.
//
// Rede de segurança: se o Supabase não estiver configurado (ou uma chamada
// falhar), o app cai no armazenamento LOCAL (IndexedDB/localStorage) em vez
// de quebrar.
//
// REMOVIDA a antiga gambiarra de caracteres invisiveis no title_number. A
// deduplicacao agora vem da CHAVE UNICA no banco (supabase-schema.sql) + da
// logica de importacao (lib/importacao/applyImport.js).
// ============================================================================

import { supabase, isSupabaseConfigured } from './supabaseClient.js';
import { createLocalEntityStorage } from './localEntityStorage.js';

export const CAMPOS_MANUAIS = [
  'current_status', 'current_motive', 'current_contact_type', 'promise_date',
  'last_contact_date', 'last_note', 'action_to_do', 'description', 'contact_count',
  'protest_requested_by', 'workflow_status', 'updated_by', 'client_category',
];

const AUTO_IMPACT_STATUSES = new Set(['pago_importacao', 'sem_carteira']);
const localStorageAdapter = createLocalEntityStorage();

const TABLE_BY_ENTITY = {
  Titulo: 'titulos',
  ChargeEvent: 'charge_events',
  ImportLog: 'import_logs',
};

const COLUMNS_BY_ENTITY = {
  Titulo: new Set([
    'id', 'source', 'client_code', 'client_name', 'client_group_key',
    'primary_client_code', 'erp_client_codes', 'record_origin', 'client_category',
    'doc_type', 'serie', 'title_number', 'seq', 'nf_servico', 'issue_date',
    'due_date', 'original_value', 'received_value', 'open_value', 'erp_balance',
    'partial_payment_detected', 'portador', 'active', 'import_file',
    'import_batch_id', 'current_status', 'current_motive', 'current_contact_type',
    'promise_date', 'last_contact_date', 'last_note', 'action_to_do',
    'contact_count', 'protest_requested_by', 'workflow_status', 'loss_status',
    'loss_date', 'loss_reason', 'updated_by', 'created_date', 'updated_date',
  ]),
  ChargeEvent: new Set([
    'id', 'titulo_id', 'client_code', 'client_name', 'event_type', 'event_subtype',
    'event_date', 'status', 'motive', 'contact_type', 'promise_date', 'note',
    'protest_requested_by', 'event_user', 'created_date', 'updated_date',
  ]),
  ImportLog: new Set([
    'id', 'file_name', 'source', 'total_read', 'inserted_count', 'updated_count',
    'deactivated_count', 'created_date', 'updated_date',
  ]),
};

const TITULO_CONFLICT = 'source,client_code,doc_type,title_number,seq,due_date';

function isFinancialImportUpdate(fields = {}) {
  if (String(fields.updated_by || '') !== 'Importação') return false;
  return fields.active === true || 'source' in fields || 'title_number' in fields ||
    'original_value' in fields || 'open_value' in fields || 'due_date' in fields;
}
function isAutomaticBaixaPayload(fields = {}) {
  return String(fields.updated_by || '') === 'Importação Automática' &&
    String(fields.workflow_status || '') === 'pago_importacao';
}
function isAutomaticCrossPayload(fields = {}) {
  return String(fields.updated_by || '') === 'Cruzamento Automático' &&
    String(fields.workflow_status || '') === 'sem_carteira';
}
function sanitizeTituloUpdate(fields = {}) {
  const next = { ...(fields || {}) };
  if (isAutomaticBaixaPayload(next) || isAutomaticCrossPayload(next)) {
    return { blocked: true, fields: next };
  }
  if (isFinancialImportUpdate(next) && AUTO_IMPACT_STATUSES.has(String(next.workflow_status || ''))) {
    next.workflow_status = 'normal';
    if (String(next.current_status || '') === 'Pago Aguard. Baixa') next.current_status = 'Não Contatado';
    const motivo = String(next.current_motive || '').toLowerCase();
    if (motivo.includes('saiu da carteira') || motivo.includes('sem carteira correspondente')) next.current_motive = null;
    next.updated_by = 'Importação';
  }
  return { blocked: false, fields: next };
}

function sameValue(left, right) { return String(left ?? '').trim() === String(right ?? '').trim(); }
function matches(row, criteria = {}) {
  return Object.entries(criteria || {}).every(([field, expected]) => expected === undefined || sameValue(row?.[field], expected));
}
function sortRows(rows, orderBy = '') {
  if (!orderBy) return [...rows];
  const desc = String(orderBy).startsWith('-');
  const field = desc ? String(orderBy).slice(1) : String(orderBy);
  return [...rows].sort((a, b) => {
    const result = String(a?.[field] ?? '').localeCompare(String(b?.[field] ?? ''), 'pt-BR', { numeric: true });
    return desc ? -result : result;
  });
}
function orderColumn(orderBy = '') {
  const raw = String(orderBy || '');
  const desc = raw.startsWith('-');
  return { column: (desc ? raw.slice(1) : raw) || 'updated_date', ascending: !desc };
}
function pickColumns(entityName, record = {}) {
  const allowed = COLUMNS_BY_ENTITY[entityName];
  if (!allowed) return { ...record };
  const out = {};
  for (const [k, v] of Object.entries(record || {})) {
    if (allowed.has(k) && v !== undefined) out[k] = v;
  }
  return out;
}
function payloadForInsert(entityName, record = {}) {
  const clean = pickColumns(entityName, record);
  delete clean.id;
  delete clean.created_date;
  delete clean.updated_date;
  return clean;
}

function makeSupabaseEntity(entityName) {
  const table = TABLE_BY_ENTITY[entityName];
  if (!isSupabaseConfigured || !supabase || !table) return null;

  return {
    async list(orderBy, limit = 1000) {
      const { column, ascending } = orderColumn(orderBy);
      const { data, error } = await supabase.from(table).select('*').order(column, { ascending }).limit(limit);
      if (error) throw error;
      return data || [];
    },
    async filter(criteria = {}, orderBy, limit = 1000) {
      const { column, ascending } = orderColumn(orderBy);
      let query = supabase.from(table).select('*');
      for (const [k, v] of Object.entries(criteria || {})) {
        if (v !== undefined && v !== null) query = query.eq(k, v);
      }
      const { data, error } = await query.order(column, { ascending }).limit(limit);
      if (error) throw error;
      return data || [];
    },
    async create(record) {
      const { data, error } = await supabase.from(table).insert(payloadForInsert(entityName, record)).select().single();
      if (error) throw error;
      return data;
    },
    async update(id, fields) {
      const clean = pickColumns(entityName, fields);
      delete clean.id;
      clean.updated_date = new Date().toISOString();
      const { data, error } = await supabase.from(table).update(clean).eq('id', id).select().single();
      if (error) throw error;
      return data;
    },
    async bulkCreate(records = []) {
      const rows = (records || []).map((r) => payloadForInsert(entityName, r));
      if (rows.length === 0) return [];
      const q = supabase.from(table);
      const { data, error } = entityName === 'Titulo'
        ? await q.upsert(rows, { onConflict: TITULO_CONFLICT, ignoreDuplicates: true }).select()
        : await q.insert(rows).select();
      if (error) throw error;
      return data || [];
    },
    async bulkUpdate(records = []) {
      const rows = (records || [])
        .map((r) => {
          const clean = pickColumns(entityName, r);
          clean.updated_date = new Date().toISOString();
          return clean.id ? clean : null;
        })
        .filter(Boolean);
      if (rows.length === 0) return [];
      const { data, error } = await supabase.from(table).upsert(rows, { onConflict: 'id' }).select();
      if (error) throw error;
      return data || [];
    },
    subscribe(callback) {
      try {
        const channel = supabase
          .channel(`realtime:${table}:${Math.random().toString(36).slice(2)}`)
          .on('postgres_changes', { event: '*', schema: 'public', table }, () => {
            try { callback(); } catch { /* noop */ }
          })
          .subscribe();
        return () => { try { supabase.removeChannel(channel); } catch { /* noop */ } };
      } catch {
        return () => {};
      }
    },
  };
}

function makeLocalEntity(entityName) {
  return {
    async list(orderBy, limit = 1000) {
      const rows = await localStorageAdapter.read(entityName);
      return sortRows(rows, orderBy).slice(0, limit);
    },
    async filter(criteria = {}, orderBy, limit = 1000) {
      const rows = await localStorageAdapter.read(entityName);
      return sortRows(rows.filter((row) => matches(row, criteria)), orderBy).slice(0, limit);
    },
    async create(record) { return localStorageAdapter.save(entityName, record); },
    async update(id, fields) {
      if (entityName === 'Titulo') {
        const decision = sanitizeTituloUpdate(fields);
        if (decision.blocked) {
          const rows = await localStorageAdapter.read(entityName);
          return rows.find((r) => r?.id === id) || { id };
        }
        return localStorageAdapter.save(entityName, { ...(decision.fields || {}), id });
      }
      return localStorageAdapter.save(entityName, { ...(fields || {}), id });
    },
    async bulkCreate(records = []) { return localStorageAdapter.saveMany(entityName, records); },
    async bulkUpdate(records = []) {
      const out = [];
      for (const rec of records || []) out.push(await localStorageAdapter.save(entityName, rec));
      return out;
    },
    subscribe(callback) { return localStorageAdapter.subscribe(entityName, callback); },
  };
}

function makeHybridEntity(entityName) {
  const local = makeLocalEntity(entityName);
  const remote = makeSupabaseEntity(entityName);
  if (!remote) return local;

  return {
    async list(orderBy, limit = 1000) {
      try {
        const rows = await remote.list(orderBy, limit);
        try { await localStorageAdapter.write(entityName, rows); } catch { /* noop */ }
        return rows;
      } catch (error) {
        console.warn(`[dados] list ${entityName} usando cache local`, error?.message || error);
        return local.list(orderBy, limit);
      }
    },
    async filter(criteria = {}, orderBy, limit = 1000) {
      try {
        const rows = await remote.filter(criteria, orderBy, limit);
        try { await localStorageAdapter.merge(entityName, rows); } catch { /* noop */ }
        return rows;
      } catch (error) {
        console.warn(`[dados] filter ${entityName} usando cache local`, error?.message || error);
        return local.filter(criteria, orderBy, limit);
      }
    },
    async create(record) {
      const saved = await remote.create(record);
      try { await localStorageAdapter.save(entityName, saved); } catch { /* noop */ }
      return saved;
    },
    async update(id, fields) {
      let payload = fields || {};
      if (entityName === 'Titulo') {
        const decision = sanitizeTituloUpdate(payload);
        if (decision.blocked) {
          console.warn('[importação protegida] baixa automática bloqueada para não esvaziar a Carteira Geral', { id });
          const rows = await localStorageAdapter.read(entityName);
          return rows.find((r) => r?.id === id) || { id };
        }
        payload = decision.fields;
      }
      const saved = await remote.update(id, payload);
      try { await localStorageAdapter.save(entityName, saved); } catch { /* noop */ }
      return saved;
    },
    async bulkCreate(records = []) {
      const saved = await remote.bulkCreate(records);
      try { if (Array.isArray(saved) && saved.length) await localStorageAdapter.merge(entityName, saved); } catch { /* noop */ }
      return saved;
    },
    async bulkUpdate(records = []) {
      let rows = records;
      if (entityName === 'Titulo') {
        rows = (records || [])
          .map((rec) => {
            const d = sanitizeTituloUpdate(rec);
            return d.blocked ? null : { ...d.fields, id: rec.id };
          })
          .filter(Boolean);
      }
      const saved = await remote.bulkUpdate(rows);
      try { if (Array.isArray(saved) && saved.length) await localStorageAdapter.merge(entityName, saved); } catch { /* noop */ }
      return saved;
    },
    subscribe(callback) {
      const stopLocal = local.subscribe(callback);
      let stopRemote = () => {};
      try { stopRemote = remote.subscribe(callback); } catch { /* noop */ }
      return () => { stopLocal?.(); stopRemote?.(); };
    },
  };
}

const authStub = {
  async me() { throw new Error('Auth não configurado (modo GitHub/Supabase).'); },
  logout() { /* noop */ },
  redirectToLogin() { /* noop */ },
};

const functionsStub = {
  async invoke(name) {
    throw new Error(`Função de backend "${name}" indisponível fora da Base44. Painel apenas informativo.`);
  },
};

export const base44 = {
  auth: authStub,
  functions: functionsStub,
  entities: {
    Titulo: makeHybridEntity('Titulo'),
    ChargeEvent: makeHybridEntity('ChargeEvent'),
    ImportLog: makeHybridEntity('ImportLog'),
  },
};
