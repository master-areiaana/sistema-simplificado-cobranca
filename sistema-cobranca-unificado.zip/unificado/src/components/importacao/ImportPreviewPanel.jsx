import React, { useRef, useState, useMemo } from "react";
import * as XLSX from "xlsx";
import { detectSrc, fmtM, num, parseRows1253, parseRows7007 } from "@/lib/cobranca";
import AuditoriaPosImportacao from "./AuditoriaPosImportacao";

const SOURCE_LABEL = {
  FINR1253: "Topcon / FINR1253",
  RPT_7007_CONS_CAR_EB: "EB / RPT_7007",
};

const STEPS = [
  { key: "reading", label: "Lendo arquivo" },
  { key: "detecting", label: "Identificando origem" },
  { key: "comparing", label: "Comparando com Carteira" },
  { key: "summary", label: "Montando resumo" },
];

function limparRows(rawRows) {
  return (rawRows || []).map((row) => {
    const out = {};
    for (const [key, value] of Object.entries(row || {})) {
      out[String(key).replace(/^\uFEFF/, "").trim()] = value;
    }
    return out;
  });
}

function canonicalFromItem(item, source) {
  return {
    "Tipo Documento": item.tp || "",
    "Série": item.ser || "",
    "Número Documento": item.titulo || "",
    "Sequência": item.seq || "",
    "Código Cliente": item.nrCli || "",
    "Nome Cliente": item.nomeCli || "",
    "Data Emissão": item.emissao || "",
    "Data Vencimento": item.vencimento || "",
    "Valor Total (R$)": Number(item.valorOriginal || 0),
    "Receb. Parcial (R$)": Number(item.valorRecebido || 0),
    "Saldo Restante (R$)": Number(item.valorEmAberto || item.valorTotalDebito || 0),
    "Portador": item.portador || "",
    "NF Serviço": item.nfServico || "",
    _meta: {
      source_status: source === "FINR1253" ? "SOMENTE_FINR" : "SOMENTE_RPT",
      origem_detectada: source,
    },
  };
}

function normName(v) {
  return String(v ?? "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z0-9]/g, " ").replace(/\s+/g, " ").trim();
}

function isValidName(v) {
  const s = String(v ?? "").trim();
  if (!s || /^\d+$/.test(s)) return false;
  const n = normName(s);
  if (["NF", "NFE", "FAT", "REC", "TC", "EB", "NFSE"].includes(n)) return false;
  return /[A-Za-zÀ-ÿ]/.test(s) && s.replace(/[^A-Za-zÀ-ÿ]/g, "").length >= 2;
}

function countUniqueClients(items) {
  const names = new Set();
  for (const item of items || []) {
    const nome = normName(item?.nomeCli || item?.["Nome Cliente"] || "");
    if (nome.length >= 3 && isValidName(nome)) names.add(nome);
  }
  return names.size;
}

function somaValor(items) {
  let total = 0;
  for (const item of items || []) {
    total += num(item?.valorEmAberto || item?.["Saldo Restante (R$)"] || item?.valorOriginal || item?.["Valor Total (R$)"] || 0);
  }
  return total;
}

function computeAudit(consolidados, existingRecords, parsedSource) {
  const reportClients = new Set();
  let reportValue = 0;
  let reportEB = 0, reportTopcon = 0;
  for (const record of consolidados || []) {
    const nome = record["Nome Cliente"] || "";
    if (isValidName(nome)) reportClients.add(normName(nome));
    reportValue += Number(record["Saldo Restante (R$)"] || 0);
    if (parsedSource === "FINR1253") reportTopcon++;
    else reportEB++;
  }

  const carteiraClients = new Set();
  let carteiraValue = 0;
  let carteiraEB = 0, carteiraTopcon = 0;
  for (const item of existingRecords || []) {
    const nome = item.nomeCli || item.client_name || "";
    if (nome) carteiraClients.add(normName(nome));
    carteiraValue += num(item.valorOriginal || item.original_value || 0);
    const origem = item.origem || item.source || "";
    if (origem === "FINR1253") carteiraTopcon++;
    else carteiraEB++;
  }

  const novosClientes = [...reportClients].filter((c) => !carteiraClients.has(c));
  const clientesAusentes = [...carteiraClients].filter((c) => !reportClients.has(c));
  const diff = reportValue - carteiraValue;

  return {
    reportClients: reportClients.size,
    carteiraClients: carteiraClients.size,
    novosClientes,
    clientesAusentes,
    reportValue,
    carteiraValue,
    diff,
    reportEB,
    reportTopcon,
    carteiraEB,
    carteiraTopcon,
  };
}

function StatCard({ label, value, color, muted: mutedColor, border }) {
  return (
    <div style={{ border: `1px solid ${border}`, borderRadius: 8, padding: "8px 10px", textAlign: "center", boxSizing: "border-box", flex: "1 1 120px", minWidth: "max-content", overflow: "visible" }}>
      <div style={{ fontSize: 9, color: mutedColor, textTransform: "uppercase", fontWeight: 800, lineHeight: 1.2, marginBottom: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 900, color: color, whiteSpace: "nowrap", lineHeight: 1.1 }}>{value}</div>
    </div>
  );
}

function Block({ title, muted: mutedColor, children }) {
  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: mutedColor, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>{title}</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{children}</div>
    </div>
  );
}

export default function ImportPreviewPanel({ totalAtivosAnteriores, registrosAtuais = [], baixadosImportacao = [], onPreparePlan, onApplyPlan, cancelRef, t }) {
  const fileRef = useRef(null);
  const [state, setState] = useState({ status: "idle" });
  const [applying, setApplying] = useState(false);
  const [currentStep, setCurrentStep] = useState(-1);
  const [showAudit, setShowAudit] = useState(false);

  const surface = t?.surf || "#ffffff";
  const border = t?.bor || "#e5e7eb";
  const text = t?.txt || "#111827";
  const muted = t?.muted || "#6b7280";
  const primary = t?.p || "#E87722";

  const audit = useMemo(() => {
    if (!showAudit || state.status !== "ready") return null;
    return computeAudit(state.preview?.consolidados, registrosAtuais, state.parsed?.source);
  }, [showAudit, state, registrosAtuais]);

  async function prepararArquivo(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    setApplying(false);
    setShowAudit(false);
    setCurrentStep(0);
    setState({ status: "loading", message: "Lendo e validando a planilha antes de gravar..." });

    try {
      const tLeitura0 = performance.now();
      setCurrentStep(0);
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: "array", cellDates: false });
      console.info(`⚡ Pré-val: leitura = ${(performance.now() - tLeitura0).toFixed(0)}ms`);

      setCurrentStep(1);
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const objectRows = limparRows(XLSX.utils.sheet_to_json(sheet, { defval: "" }));
      const arrayRows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
      const sourceByName = detectSrc(file.name);

      const tNorm0 = performance.now();
      let items = [];
      let detectionNote = "";

      let detectedSource = sourceByName;
      if (sourceByName === "FINR1253") {
        items = parseRows1253(arrayRows);
        detectionNote = `Origem: ${SOURCE_LABEL.FINR1253}`;
      } else {
        items = parseRows7007(objectRows);
        detectionNote = `Origem: ${SOURCE_LABEL.RPT_7007_CONS_CAR_EB}`;
      }

      if (items.length === 0) {
        const altSource = sourceByName === "FINR1253" ? "RPT_7007_CONS_CAR_EB" : "FINR1253";
        const altItems = altSource === "FINR1253" ? parseRows1253(arrayRows) : parseRows7007(objectRows);
        if (altItems.length > 0) {
          items = altItems;
          detectedSource = altSource;
          detectionNote = `Origem corrigida: ${SOURCE_LABEL[altSource]}`;
        }
      }
      console.info(`⚡ Pré-val: normalização = ${(performance.now() - tNorm0).toFixed(0)}ms (${items.length} itens)`);

      if (items.length === 0) {
        setState({ status: "error", message: `Nenhum título válido em ${file.name}.` });
        setCurrentStep(-1);
        return;
      }

      setCurrentStep(2);
      const consolidados = items.map((item) => canonicalFromItem(item, detectedSource));
      const totalAberto = somaValor(consolidados);
      const carteiraOrigemCount = (registrosAtuais || []).filter((r) => {
        const src = r?.source || r?.origem || "";
        return src === detectedSource && r?.active !== false;
      }).length;
      const isParcial = carteiraOrigemCount > 0 && consolidados.length > 0 && consolidados.length < carteiraOrigemCount * 0.7;
      const isVazio = consolidados.length === 0;
      const seguranca = {
        importacaoParcial: isParcial || isVazio,
        podeProsseguir: !isVazio,
        podeAplicarBaixaAutomatica: !isParcial && !isVazio,
        bloqueios: isVazio ? ["Arquivo vazio ou sem títulos válidos"] : isParcial ? [`Importação parcial: ${consolidados.length} títulos na planilha vs ${carteiraOrigemCount} na carteira desta origem`] : [],
      };
      const preview = {
        consolidados,
        finrItems: detectedSource === "FINR1253" ? consolidados : [],
        rptItems: detectedSource === "RPT_7007_CONS_CAR_EB" ? consolidados : [],
        seguranca,
        resumo: { totalConsolidados: consolidados.length },
        estatisticas: {
          arquivo: file.name,
          origem: detectedSource,
          totalLinhas: Math.max(objectRows.length, arrayRows.length),
          totalValidos: consolidados.length,
          totalAberto,
        },
      };

      const tPlan0 = performance.now();
      const plan = await onPreparePlan?.(preview, file.name);
      console.info(`⚡ Pré-val: plano (indexação+comparação+baixas) = ${(performance.now() - tPlan0).toFixed(0)}ms`);
      setCurrentStep(3);

      setState({
        status: "ready",
        fileName: file.name,
        preview,
        plan,
        parsed: { source: detectedSource, detectionNote, totalRows: preview.estatisticas.totalLinhas },
        message: `${file.name} validado: ${consolidados.length} título(s), ${fmtM(totalAberto)} em aberto.`,
      });
      setCurrentStep(-1);
    } catch (error) {
      setState({ status: "error", message: `Erro: ${error.message}` });
      setCurrentStep(-1);
    }
  }

  async function aplicarPlano() {
    if (!state.plan || !state.preview || applying) return;
    setApplying(true);
    if (cancelRef) cancelRef.current = false;
    setState((prev) => ({ ...prev, status: "applying", message: "Aplicando...", progress: 0 }));
    try {
      const result = await onApplyPlan?.(state.plan, state.preview, state.fileName, (msg, progress) => {
        setState((prev) => ({ ...prev, message: msg, progress: typeof progress === "number" ? progress : prev.progress }));
      });
      const blockedMsg = result?.blocked > 0 ? `, ${result.blocked} para revisão` : "";
      setState((prev) => ({ ...prev, status: "done", message: `Importação aplicada: ${result?.created || 0} novo(s), ${result?.updated || 0} atualizado(s), ${result?.lowered || 0} baixado(s)${blockedMsg}.`, progress: 1 }));
    } catch (error) {
      setState((prev) => ({ ...prev, status: state.status === "applying" && cancelRef?.current ? "done" : "error", message: error.message, progress: null }));
    } finally {
      setApplying(false);
    }
  }

  const canApply = state.status === "ready" && state.plan?.canApply && !applying;
  const stats = state.preview?.estatisticas || {};
  const planSummary = state.plan?.summary || {};
  const carteiraValor = useMemo(() => registrosAtuais.reduce((s, r) => s + num(r.valorOriginal || r.original_value || 0), 0), [registrosAtuais]);

  return (
    <section style={{ background: surface, border: `1px solid ${border}`, borderRadius: 10, padding: 12, marginBottom: 12, color: text, boxSizing: "border-box", overflow: "hidden" }}>
      <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" hidden onChange={prepararArquivo} />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div style={{ fontSize: 13, fontWeight: 800 }}>Pré-validação da importação</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button type="button" onClick={() => fileRef.current?.click()} disabled={state.status === "loading" || state.status === "applying"} style={{ background: primary, color: "#fff", border: "none", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>Validar planilha</button>
          <button type="button" onClick={aplicarPlano} disabled={!canApply} style={{ background: canApply ? "#16a34a" : "#9ca3af", color: "#fff", border: "none", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 800, cursor: canApply ? "pointer" : "not-allowed", display: "flex", alignItems: "center", gap: 6 }}>
            {(state.status === "applying" || state.status === "loading") && <span style={{ display: "inline-block", width: 12, height: 12, border: "2px solid #ffffff44", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />}
            Aplicar importação segura
          </button>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>

      {state.message && <div style={{ marginTop: 8, fontSize: 12, color: state.status === "error" ? "#dc2626" : state.status === "done" ? "#16a34a" : text, whiteSpace: "normal", wordBreak: "break-word" }}>{state.message}</div>}

      {state.status === "applying" && typeof state.progress === "number" && (
        <div style={{ marginTop: 8 }}>
          <div style={{ height: 8, background: "#e5e7eb", borderRadius: 4, overflow: "hidden", marginBottom: 6 }}>
            <div style={{ width: `${Math.round(state.progress * 100)}%`, height: "100%", background: primary, transition: "width 0.2s ease", borderRadius: 4 }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 10, color: muted, fontWeight: 700 }}>{Math.round(state.progress * 100)}%</span>
            {cancelRef && (
              <button type="button" onClick={() => { cancelRef.current = true; }} style={{ background: "#ef4444", color: "#fff", border: "none", borderRadius: 6, padding: "4px 12px", fontSize: 11, fontWeight: 800, cursor: "pointer" }}>⏹ Cancelar</button>
            )}
          </div>
        </div>
      )}

      {currentStep >= 0 && (
        <div style={{ marginTop: 8, display: "flex", gap: 4, flexWrap: "wrap" }}>
          {STEPS.map((step, idx) => (
            <div key={step.key} style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <div style={{ width: 18, height: 18, borderRadius: "50%", background: idx < currentStep ? "#16a34a" : idx === currentStep ? primary : "#d1d5db", color: "#fff", fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{idx < currentStep ? "✓" : idx + 1}</div>
              <span style={{ fontSize: 9, color: idx <= currentStep ? text : muted, fontWeight: idx === currentStep ? 800 : 600, whiteSpace: "nowrap" }}>{step.label}</span>
              {idx < STEPS.length - 1 && <span style={{ color: "#d1d5db", fontSize: 9 }}>→</span>}
            </div>
          ))}
        </div>
      )}

      {state.status === "ready" && (
        <>
          <Block title="Carteira atual" muted={muted}>
            <StatCard label="Clientes atuais" value={totalAtivosAnteriores || 0} color={text} muted={muted} border={border} />
            <StatCard label="Títulos atuais" value={totalAtivosAnteriores || 0} color={text} muted={muted} border={border} />
            <StatCard label="Valor em aberto" value={fmtM(carteiraValor)} color="#f59e0b" muted={muted} border={border} />
          </Block>

          <Block title="Relatório importado" muted={muted}>
            <StatCard label="Origem" value={state.parsed?.source === "FINR1253" ? "Topcon" : "EB"} color="#7c3aed" muted={muted} border={border} />
            <StatCard label="Clientes na planilha" value={countUniqueClients(state.preview?.consolidados)} color="#3b82f6" muted={muted} border={border} />
            <StatCard label="Títulos na planilha" value={stats.totalValidos || 0} color="#3b82f6" muted={muted} border={border} />
            <StatCard label="Valor total" value={fmtM(stats.totalAberto || 0)} color="#f59e0b" muted={muted} border={border} />
            <StatCard label="Linhas lidas" value={stats.totalLinhas || 0} color="#6b7280" muted={muted} border={border} />
            <StatCard label="Registros válidos" value={stats.totalValidos || 0} color="#10b981" muted={muted} border={border} />
          </Block>

          {state.preview?.seguranca?.importacaoParcial && (
            <div style={{ marginTop: 8, padding: "8px 12px", background: "#fef3c7", border: "1px solid #f59e0b", borderRadius: 6, fontSize: 11, color: "#92400e", fontWeight: 700 }}>
              ⚠️ Importação parcial detectada — baixa automática bloqueada por segurança. Títulos ausentes ficarão para revisão do gestor.
            </div>
          )}
          <Block title={`Plano da importação — ${state.parsed?.source === "FINR1253" ? "Topcon" : "EB"}`} muted={muted}>
            <StatCard label="Novos" value={planSummary.totalCreate || 0} color="#10b981" muted={muted} border={border} />
            <StatCard label="Atualizar" value={planSummary.totalUpdate || 0} color="#3b82f6" muted={muted} border={border} />
            <StatCard label="Manter" value={planSummary.totalUnchanged || 0} color="#6b7280" muted={muted} border={border} />
            <StatCard label="Baixar ausência" value={planSummary.totalAbsence || 0} color="#8b5cf6" muted={muted} border={border} />
            <StatCard label="Baixas bloqueadas" value={planSummary.totalAbsenceBlocked || 0} color="#ef4444" muted={muted} border={border} />
            <StatCard label="Revisar" value={planSummary.totalNeedsReview || 0} color="#f59e0b" muted={muted} border={border} />
          </Block>

          <div style={{ marginTop: 10 }}>
            <button type="button" onClick={() => setShowAudit((v) => !v)} style={{ background: "transparent", border: `1px solid ${border}`, borderRadius: 6, padding: "6px 12px", fontSize: 11, fontWeight: 700, color: text, cursor: "pointer" }}>
              {showAudit ? "▲ Ocultar auditoria" : "▼ Ver auditoria detalhada"}
            </button>
          </div>

          {showAudit && audit && (
            <div style={{ marginTop: 10, borderTop: `1px solid ${border}`, paddingTop: 10 }}>
              <Block title="Divergências — relatório × Carteira" muted={muted}>
                <StatCard label="Clientes no relatório" value={audit.reportClients} color="#3b82f6" muted={muted} border={border} />
                <StatCard label="Clientes na Carteira" value={audit.carteiraClients} color="#6b7280" muted={muted} border={border} />
                <StatCard label="Novos (no relatório)" value={audit.novosClientes.length} color="#10b981" muted={muted} border={border} />
                <StatCard label="Não encontrados (só Carteira)" value={audit.clientesAusentes.length} color="#ef4444" muted={muted} border={border} />
              </Block>

              <Block title="Valores — relatório × Carteira" muted={muted}>
                <StatCard label="Valor no relatório" value={fmtM(audit.reportValue)} color="#f59e0b" muted={muted} border={border} />
                <StatCard label="Valor na Carteira" value={fmtM(audit.carteiraValue)} color="#10b981" muted={muted} border={border} />
                <StatCard label="Diferença" value={fmtM(audit.diff)} color={Math.abs(audit.diff) < 0.01 ? "#10b981" : "#ef4444"} muted={muted} border={border} />
              </Block>

              <Block title="Valores por origem" muted={muted}>
                <StatCard label="Relatório: títulos EB" value={audit.reportEB} color="#0369a1" muted={muted} border={border} />
                <StatCard label="Relatório: títulos Topcon" value={audit.reportTopcon} color="#7c3aed" muted={muted} border={border} />
                <StatCard label="Carteira: títulos EB" value={audit.carteiraEB} color="#0369a1" muted={muted} border={border} />
                <StatCard label="Carteira: títulos Topcon" value={audit.carteiraTopcon} color="#7c3aed" muted={muted} border={border} />
              </Block>

              {audit.novosClientes.length > 0 && (
                <div style={{ marginTop: 8, fontSize: 11, color: muted }}>
                  <b>Novos clientes ({audit.novosClientes.length}):</b> {audit.novosClientes.slice(0, 10).join(", ")}{audit.novosClientes.length > 10 ? "..." : ""}
                </div>
              )}
              {audit.clientesAusentes.length > 0 && (
                <div style={{ marginTop: 4, fontSize: 11, color: muted }}>
                  <b>Clientes ausentes ({audit.clientesAusentes.length}):</b> {audit.clientesAusentes.slice(0, 10).join(", ")}{audit.clientesAusentes.length > 10 ? "..." : ""}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {state.plan?.reviewRequired?.length > 0 && (
        <div style={{ marginTop: 8, fontSize: 12, color: "#dc2626" }}>Títulos ambíguos para revisar. Aplicação bloqueada.</div>
      )}

      {state.status === "done" && state.plan && state.preview && (
        <AuditoriaPosImportacao
          plan={state.plan}
          preview={state.preview}
          registrosAtuais={registrosAtuais}
          baixadosImportacao={baixadosImportacao}
          importSource={state.parsed?.source}
          t={t}
        />
      )}
    </section>
  );
}